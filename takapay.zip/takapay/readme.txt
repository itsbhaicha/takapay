=== TakaPay ===
Contributors: TakaPay
Tags: takapay, bkash, nagad, rocket, woocommerce-gateway
Requires at least: 6.0
Tested up to: 7.0
Stable tag: 2.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

takapay WooCommerce Plugin for receiving payments with automation.

== Description ==

takapay WooCommerce Plugin enables seamless payment processing through your personal account with automation.

== Features ==

* Digital Product Support
* Fee System
* Block Checkout
* Multiple Payment Methods
* And many more...

== Supported Gateways ==

* bKash
* Rocket
* Nagad
* Upay
* Cellfin
* All Bangladeshi Mobile Banks
* Binance
* Perfect Money
* Multiple Banks

== Frequently Asked Questions ==

= What is TakaPay? =
TakaPay is a WooCommerce payment gateway that allows users to receive payments through various Bangladeshi mobile banking platforms and international payment methods.

= Does it support automated transactions? =
Yes, transactions are processed automatically once configured properly.

== Changelog ==

= 2.0.0 =
* Updated: Icon visibility System integration
* Updated: Custom logo System
* Updated: Stable tag versioning
* Minor bug fixes and stability improvements

= 1.0.1 =  
* WordPress compatibility updated to 6.8  
* Minor improvements and optimizations

= 1.0.0 =  
* Initial release