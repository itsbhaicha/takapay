<?php
/*
 * Plugin Name: TakaPay
 * Plugin URI: https://wordpress.org/plugins/takapay
 * Description: takapay WooCommerce Plugin. You can receive payment through your personal account with Automation.
 * Author: TakaPay
 * Author URI: https://github.com/itsbhaicha/takapay
 * Version: 2.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: takapay
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('plugins_loaded', 'takapay_check_woocommerce');
function takapay_check_woocommerce() {
    if (class_exists('WooCommerce')) {
        require_once plugin_dir_path(__FILE__) . 'includes/class-wc-takapay-gateway.php';
        require_once plugin_dir_path(__FILE__) . 'includes/class-wc-takapay-settings.php';
        require_once plugin_dir_path(__FILE__) . 'includes/class-wc-takapay-webhook.php';

        add_filter('woocommerce_payment_gateways', 'takapay_add_gateway_class');
        function takapay_add_gateway_class($gateways) {
            $gateways[] = 'WC_takapay_Gateway';
            return $gateways;
        }

        add_action('rest_api_init', function () {
            register_rest_route('takapay/v1', '/webhook', array(
                'methods'             => 'POST',
                'callback'            => 'takapay_handle_webhook',
                'permission_callback' => '__return_true'
            ));
        });

        add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'takapay_plugin_action_links');
    } else {
        add_action('admin_notices', function () {
            // WordPress review rules অনুযায়ী admin notice অবশ্যই escape (esc_html_e) করতে হবে
            echo '<div class="error"><p><strong>';
            esc_html_e('TakaPay', 'takapay');
            echo '</strong> ';
            esc_html_e('requires WooCommerce to be installed and activated.', 'takapay');
            echo '</p></div>';
        });
    }
}

// ফাংশনের নাম এবং ভেতরের টেক্সট ডোমেইন 'rupantorpay' থেকে 'takapay' তে ফিক্স করা হয়েছে
function takapay_plugin_action_links($links) {
    $plugin_links = [
        sprintf(
            '<a href="%s">%s</a>',
            esc_url(admin_url('admin.php?page=wc-settings&tab=checkout&section=takapay')),
            __('Settings', 'takapay')
        ),
        sprintf(
            '<a href="%s" target="_blank">%s</a>',
            esc_url('https://takapay.shop'),
            // WordPress-এ অনুবাদের ভেতরের টেক্সটে স্টাইল বা HTML ট্যাগ ব্যবহার না করাই ভালো, তাই পিওর টেক্সট রাখা হলো
            __('Purchase Plan', 'takapay')
        ),
    ];
    return array_merge($plugin_links, $links);
}