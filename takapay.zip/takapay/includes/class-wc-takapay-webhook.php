<?php

if (!defined('ABSPATH')) {
    exit;
}

function takapay_handle_webhook($request)
{
    // ১. REST API-তে $_GET/$_REQUEST বা Nonce ব্যবহার করা যাবে না। 
    // বডি থেকে JSON বা POST ডেটা নেওয়ার সঠিক নিয়ম হলো $request->get_json_params() অথবা get_params()
    $params = $request->get_params();

    if (empty($params['order_id']) || !is_numeric($params['order_id'])) {
        return new WP_Error(
            'rest_invalid_order',
            esc_html__('Invalid or missing order ID.', 'takapay'),
            array('status' => 400)
        );
    }

    // ২. অর্ডার আইডি স্যানিটাইজ এবং ভ্যালিডেশন
    $order_id = absint($params['order_id']);
    $order    = wc_get_order($order_id);

    if (!$order) {
        return new WP_Error(
            'rest_order_not_found',
            esc_html__('Order not found.', 'takapay'),
            array('status' => 404)
        );
    }

    // ৩. গেটওয়ে ক্লাস কল করে স্ট্যাটাস আপডেট করা
    if (class_exists('WC_takapay_Gateway')) {
        $gateway = new WC_takapay_Gateway();
        // আপনার মেথডের রিকোয়ারমেন্ট অনুযায়ী পুরো $order অবজেক্ট অথবা শুধু $order_id পাস করুন
        $gateway->update_order_status($order);
    }

    // ৪. REST API-তে সরাসরি echo wp_json_encode বা status_header ব্যবহার করা নিষিদ্ধ।
    // এখানে সরাসরি WP_REST_Response রিটার্ন করতে হবে।
    return new WP_REST_Response(
        array(
            'success' => true,
            'message' => esc_html__('Webhook received and processed.', 'takapay')
        ),
        200
    );
}