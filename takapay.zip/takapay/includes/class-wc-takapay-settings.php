<?php

if (!defined('ABSPATH')) {
    exit;
}

return array(
    'enabled' => array(
        'title'       => __('Enable/Disable', 'takapay'),
        'label'       => __('Enable TakaPay', 'takapay'),
        'type'        => 'checkbox',
        'description' => '',
        'default'     => 'no'
    ),
    'icon_enable' => array(
        'title'       => __('Show Icon on Checkout', 'takapay'),
        'type'        => 'checkbox',
        'label'       => __('Enable Icon Display', 'takapay'),
        'default'     => 'yes',
        'description' => __('If checked, an icon will be shown on the checkout page.', 'takapay'),
    ),
    'title' => array(
        'title'       => __('Title', 'takapay'),
        'type'        => 'text',
        'description' => __('This controls the title which the user sees during checkout.', 'takapay'),
        'default'     => 'TakaPay Gateway', // প্লাগইনের অফিশিয়াল বানানের সাথে মিলানো হলো
        'desc_tip'    => true,
    ),
    'description' => array(
        'title'       => __('Description', 'takapay'),
        'type'        => 'textarea',
        'description' => __('This controls the description which the user sees during checkout.', 'takapay'),
        'default'     => 'Pay securely via Bangladeshi payment methods.',
        'desc_tip'    => true,
    ),
    'apikeys' => array(
        'title'       => __('API Key', 'takapay'),
        'type'        => 'text',
        // ফিক্স: অনুবাদের ভেতর থেকে HTML লিংক বের করে sprintf এবং esc_url ব্যবহার করা হয়েছে
        'description' => sprintf(
            /* translators: %s: Link to TakaPay brand panel */
            __('Get your API key from %s.', 'takapay'),
            '<a href="' . esc_url('https://takapay.com/user/brands') . '" target="_blank">' . esc_html__('Panel &rarr; Brands', 'takapay') . '</a>'
        ),
        'default'     => '', // সিকিউরিটি নিশ্চিত করতে ডিফল্ট হ্যাশ (#) ফাঁকা রাখা হলো
        'desc_tip'    => false,
    ),
    'physical_product_status' => array(
        'title'       => __('Physical Product Status', 'takapay'),
        'type'        => 'select',
        'options'     => array(
            'wc-processing' => __('Processing', 'takapay'),
            'wc-completed'  => __('Completed', 'takapay'),
            'wc-on-hold'    => __('On Hold', 'takapay'),
        ),
        'description' => __('Select status for physical product orders after successful payment.', 'takapay'),
        'default'     => 'wc-processing',
        'desc_tip'    => false,
    ),
    'digital_product_status' => array(
        'title'       => __('Digital Product Status', 'takapay'),
        'type'        => 'select',
        'options'     => array(
            'wc-processing' => __('Processing', 'takapay'),
            'wc-completed'  => __('Completed', 'takapay'),
            'wc-on-hold'    => __('On Hold', 'takapay'),
        ),
        'description' => __('Select status for digital/downloadable product orders after successful payment.', 'takapay'),
        'default'     => 'wc-completed',
        'desc_tip'    => false,
    ),
    'currency_rate' => array(
        'title'       => __('USD to BDT Exchange Rate', 'takapay'),
        'type'        => 'number',
        'description' => __('This rate will be applied to convert the total amount to BDT.', 'takapay'),
        'default'     => '110',
        'desc_tip'    => true,
    ),
    'payment_site' => array(
        'title'             => __('Payment Site URL', 'takapay'),
        'type'              => 'text',
        'description'       => '',
        'default'           => 'https://secure-pay.takapay.com/',
        'desc_tip'          => true,
        'custom_attributes' => array(
            'readonly' => 'readonly'
        ),
    ),
    'custom_icon' => array(
        'title'       => __('Custom Icon Image', 'takapay'),
        'type'        => 'text',
        'description' => __('Upload an image from the media library.', 'takapay'),
        'default'     => '',
        'desc_tip'    => true,
        'custom_attributes' => array(
            'class' => 'wc-enhanced-select',
            'style' => 'width: 300px;',
        ),
    ),
);