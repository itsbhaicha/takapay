<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_takapay_Gateway extends WC_Payment_Gateway
{
    public function __construct()
    {
        $this->id = 'takapay';
        $this->has_fields = false;
        $this->method_title = __('TakaPay', 'takapay');
        
        // ফিক্স ১: অনুবাদের ভেতর থেকে HTML লিংক বের করে sprintf দিয়ে ডাইনামিক করা হলো
        $this->method_description = sprintf(
            /* translators: %s: Link to TakaPay website */
            __('Accept Bangladeshi payments via multiple gateways including bKash, Nagad, Rocket, and more.<br> %s', 'takapay'),
            '<a href="' . esc_url('https://takapay.shop') . '" target="_blank">' . esc_html__('Sign up for a TakaPay account', 'takapay') . '</a>'
        );
        
        $this->supports = array('products');
        
        $this->init_form_fields();
        $this->init_settings();
        
        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');
        $this->enabled = $this->get_option('enabled');
        $this->icon_enable = $this->get_option('icon_enable', 'yes') === 'yes';
        $custom_icon_url = $this->get_option('custom_icon');
        
        if ($this->icon_enable) {
            $this->icon = !empty($custom_icon_url) ? esc_url($custom_icon_url) : plugins_url('../assets/logo.png', __FILE__);
        } else {
            $this->icon = '';
        }
        
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_api_' . strtolower(get_class($this)), array($this, 'handle_webhook'));
    }

    public function init_form_fields()
    {
        $this->form_fields = require plugin_dir_path(__FILE__) . 'class-wc-takapay-settings.php';
    }

    public function process_payment($order_id)
    {
        $order = wc_get_order($order_id);
        $current_user = wp_get_current_user();
        $total = $order->get_total();

        if ($order->get_currency() == 'USD') {
            $total = $total * (float) $this->get_option('currency_rate');
        }
        
        if ($order->get_status() != 'completed') {
            $order->update_status('pending', esc_html__('Customer is being redirected to TakaPay', 'takapay'));
        }
        
        $data = array(
            "fullname"    => !empty($current_user->user_firstname) ? sanitize_text_field($current_user->user_firstname) : sanitize_text_field($current_user->display_name),
            "email"       => sanitize_email($current_user->user_email),
            "amount"      => (float) $total,
            "webhook_url" => site_url('/?wc-api=wc_takapay_gateway&order_id=' . $order->get_id()),
            "success_url" => $this->get_return_url($order),
            "cancel_url"  => wc_get_checkout_url()
        );
        
        // ফিক্স ২: $_SERVER['HTTP_HOST'] স্যানিটাইজ করা হলো
        $http_host = isset($_SERVER['HTTP_HOST']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_HOST'])) : '';

        $headers = array(
            'Content-Type' => 'application/json',
            'X-API-KEY'    => $this->get_option('apikeys'),
            'X-CLIENT'     => $http_host,
        );    
        
        $url = $this->get_option('payment_site') . "api/payment/checkout";
        $response = $this->create_payment($url, $data, $headers);
        $data = json_decode($response, true);
        
        if (isset($data['payment_url'])) {
            return array(
                'result'   => 'success',
                'redirect' => esc_url_raw($data['payment_url'])
            );
        } else {
            // ফিক্স ৩ (স্ক্রিনশটের মূল এরর): অনুবাদ ফাংশনের ভেতর কনক্যাটিনেশন তুলে দিয়ে sprintf ব্যবহার করা হলো
            $error_message = isset($data['message']) ? sanitize_text_field($data['message']) : __('Unknown error occurred.', 'takapay');
            wc_add_notice(sprintf(__('Payment error: %s', 'takapay'), $error_message), 'error');
            return;
        }
    }

    public function create_payment($url, $data, $headers)
    {
        $args = array(
            'headers' => $headers,
            'body'    => wp_json_encode($data),
            'timeout' => 10,
        );

        $response = wp_remote_post(esc_url_raw($url), $args);

        if (is_wp_error($response)) {
            return wp_json_encode(["status" => 0, "message" => "Request failed"]);
        }

        return wp_remote_retrieve_body($response);
    }

    public function update_order_status($order)
    {
        if (!isset($_REQUEST['transactionId'])) {
            wp_die(esc_html__('Invalid request. Transaction ID missing.', 'takapay'));
        }

        $transactionId = sanitize_text_field(wp_unslash($_REQUEST['transactionId']));
        
        if (isset($_REQUEST['status'])) {
            $status = sanitize_text_field(wp_unslash($_REQUEST['status']));
            
            if ($status === 'completed' || $status === '2') {
                $data = array(
                    "transaction_id" => $transactionId,
                );
                $headers = array(
                    'Content-Type' => 'application/json',
                    'X-API-KEY'    => $this->get_option('apikeys'),
                );

                $url = $this->get_option('payment_site') . "api/payment/verify-payment";
                $response = $this->create_payment($url, $data, $headers);
                $data = json_decode($response, true);
                
                if ($order->get_status() != 'completed') {
                    if (isset($data['status']) && ($data['status'] == "COMPLETED" || $data['status'] == "2")) {
                        $transaction_id = sanitize_text_field($data['trx_id'] ?? $data['transaction_id']);
                        $amount = sanitize_text_field($data['amount']);
                        $sender_number = sanitize_text_field($data['email']);
                        $payment_method = 'takapay';
                        $has_digital_products = false;
                        
                        foreach ($order->get_items() as $item) {
                            $product = $item->get_product();
                            if ($product && $product->is_downloadable()) {
                                $has_digital_products = true;
                                break;
                            }
                        }
                        
                        if ($has_digital_products) {
                            $order->update_status(
                                $this->get_option('digital_product_status'),
                                sprintf(
                                    __('TakaPay payment was successfully completed. Payment Method: %1$s, Amount: %2$s, Transaction ID: %3$s, Email: %4$s', 'takapay'),
                                    $payment_method,
                                    $amount,
                                    $transaction_id,
                                    $sender_number
                                )
                            );
                        } else {
                            $order->update_status(
                                $this->get_option('physical_product_status'),
                                sprintf(
                                    __('TakaPay payment was successfully processed. Payment Method: %1$s, Amount: %2$s, Transaction ID: %3$s, Email: %4$s', 'takapay'),
                                    $payment_method,
                                    $amount,
                                    $transaction_id,
                                    $sender_number
                                )
                            );
                        }

                        // ফিক্স ৪: উকমার্স লেটেস্ট স্ট্যান্ডার্ড অনুযায়ী স্টক কমানো
                        wc_reduce_stock_levels($order->get_id());
                        $order->payment_complete($transaction_id);
                        return true;
                    } else {
                        $order->update_status('on-hold', esc_html__('TakaPay payment is on hold. Transaction ID not found. Please check it manually.', 'takapay'));
                        return true;
                    }
                }
            } elseif ($status === 'pending' || $status === '0') {
                $order->update_status('pending', esc_html__('TakaPay payment is pending.', 'takapay'));
                return true;
            } elseif ($status === 'cancelled' || $status === '3') {
                $order->update_status('cancelled', esc_html__('TakaPay payment was cancelled.', 'takapay'));
                return true;
            } else {
                $order->update_status('on-hold', esc_html__('TakaPay payment status is unknown. Please check it manually.', 'takapay'));
                return true;
            }
        }
    }

    public function handle_webhook()
    {
        if (empty($_GET['order_id']) || !is_numeric($_GET['order_id'])) {
            wp_die(esc_html__('Invalid request.', 'takapay'));
        }
        $order_id = absint($_GET['order_id']);
        $order = wc_get_order($order_id);
        if ($order) {
            $this->update_order_status($order);
        }
        status_header(200);
        echo wp_json_encode(['message' => esc_html__('Webhook received and processed.', 'takapay')]);
        exit();
    }
}